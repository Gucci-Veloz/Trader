
# 📥 ASK_USER.md — Consulta Inicial al Usuario

Solicitar al Usuario la siguiente información:

- 🏷 **Par** (consultar al usuario por el nombre)
- 🖼 **Imagen 1**: Temporalidad de **1 Día**
- 🖼 **Imagen 2**: Timeframe **4H**
- 🖼 **Imagen 3**: Timeframe **1H**
- 🖼 **Imagen 4**: Timeframe **15 mins**
- 🖼 **Imagen 5**: Timeframe **1 mins**
- 📊 **Imagen 6**: RSI + MACD + Volumen en **TF 4H**
- 📊 **Imagen 7**: RSI + MACD + Volumen en **TF 1H**
- 📊 **Imagen 8**: RSI + MACD + Volumen en **TF 15 mins**

---

🎯 Luego de recibir las imágenes, genera la respuesta con base al "FORMATO_DE_RESPUESTA.md"

> “Entradas con punto de entrada, tipo de entradas: scalping y swing, dame nivel de efectividad, y si es long o short”
